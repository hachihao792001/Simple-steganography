#pragma once
#include <iostream>
#include <stack>
using namespace std;

void SelectionSort(int* a, int n);

void InsertionSort(int* a, int n);

void BubbleSort(int* a, int n);

void CreateSubArray(int* arr, int*& subArr, int l, int r);

void Merge(int*& arr, int l, int* a, int na, int* b, int nb);

void MergeSort(int* arr, int n);

void MergeSort(int* arr, int l, int r);

void QuickSort(int* a, int n);

void vunDong(int* arr, int n, int i);

void HeapSort(int* arr, int n);

int BinarySearch(int* a, int left, int right, int key);

void BinaryInsertionSort(int* a, int n);
