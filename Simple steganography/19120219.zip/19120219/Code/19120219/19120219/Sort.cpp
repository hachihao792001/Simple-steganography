#include "Sort.h"

void SelectionSort(int* a, int n) {
	for (int i = 0; i < n - 1; i++) {
		int currentMin = i;
		for (int j = i + 1; j < n; j++) {
			if (a[j] < a[currentMin])
				currentMin = j;
		}
		swap(a[i], a[currentMin]);
	}
}

void InsertionSort(int* a, int n) {
	for (int i = 1; i < n; i++) {
		if (a[i] < a[i - 1]) {
			int key = a[i];
			for (int j = i; j >= 0; j--) {
				if (a[j - 1] > key)
					a[j] = a[j - 1];
				else {
					a[j] = key;
					break;
				}
			}
		}
	}
}

void BubbleSort(int* a, int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1; j++) {
			if (a[j] > a[j + 1])
				swap(a[j], a[j + 1]);
		}
	}
}

void CreateSubArray(int* arr, int*& subArr, int l, int r) {
	int n = r - l + 1;
	subArr = new int[n];
	int k = 0;
	for (int i = l; i <= r; i++)
		subArr[k++] = arr[i];
}

void Merge(int*& arr, int l, int* a, int na, int* b, int nb) {
	int i = 0, j = 0, k = l;
	while (i < na && j < nb) {
		if (a[i] <= b[j]) arr[k++] = a[i++];
		else arr[k++] = b[j++];
	}

	while (i < na)
		arr[k++] = a[i++];
	while (j < nb)
		arr[k++] = b[j++];
}

void MergeSort(int* arr, int n) {
	MergeSort(arr, 0, n - 1);
}

void MergeSort(int* arr, int l, int r) {
	if (l >= r) return;
	int mid = (l + r) / 2;
	int* a, * b;

	CreateSubArray(arr, a, l, mid);
	CreateSubArray(arr, b, mid + 1, r);

	MergeSort(a, 0, mid - l);
	MergeSort(b, 0, r - mid - 1);

	Merge(arr, l, a, mid - l + 1, b, r - mid);

	delete[]a;
	delete[]b;
}

void QuickSort(int* a, int n) {
	//khong de quy vi bi stackoverflow
	stack<int> qsStack;
	int l, r;
	qsStack.push(0);
	qsStack.push(n - 1);

	while (!qsStack.empty()) {
		r = qsStack.top();
		qsStack.pop();
		l = qsStack.top();
		qsStack.pop();

		int pivot = a[r];
		int i = l, j = r;

		while (i <= j) {
			while (a[i] < pivot) i++;
			while (a[j] > pivot) j--;
			if (i <= j) {
				swap(a[i], a[j]);
				i++;
				j--;
			}
		}

		if (l < j) {
			qsStack.push(l);
			qsStack.push(j);
		}
		if (i < r) {
			qsStack.push(i);
			qsStack.push(r);
		}
	}
}

void vunDong(int* arr, int n, int root) {
	int Key, c = 0;
	Key = arr[root];
	while (root * 2 + 1 < n) {
		if ((arr[root * 2 + 1] < arr[root * 2 + 2]) && (c < n - 1))
			c = root * 2 + 2;
		else
			c = root * 2 + 1;

		if (arr[c] <= Key)  break;
		arr[root] = arr[c];
		root = c;
	}
	arr[root] = Key;
}

void HeapSort(int* arr, int n) {
	for (int i = n / 2 - 1; i >= 0; i--)
		vunDong(arr, n, i);
	for (int i = n - 1; i > 0; i--) {
		swap(arr[0], arr[i]);
		vunDong(arr, i, 0);
	}
}


int BinarySearch(int* a, int left, int right, int key) {
	if (left >= right) {
		if (a[left] < key) return left + 1;
		else return left;
	}

	int mid = (right + left) / 2;
	if (key == a[mid]) return mid + 1;
	if (key < a[mid]) return BinarySearch(a, left, mid, key);
	else return BinarySearch(a, mid + 1, right, key);
}

void BinaryInsertionSort(int* a, int n) {
	int key, pos;
	for (int i = 1; i < n; i++) {
		key = a[i];
		pos = BinarySearch(a, 0, i - 1, a[i]);

		for (int j = i; j >= pos; j--)
			a[j] = a[j - 1];
		a[pos] = key;
	}
}