#include <iostream>
#include "Sort.h"
#include "CalTime.h"
#include "DataGenerator.h"
#include <fstream>
using namespace std;

int main() {
	fstream out("output.txt", ios::out);

	const int ORDER_COUNT = 4;
	const int SIZE_COUNT = 5;
	const int SORTINGALG_COUNT = 7;

	string orderName[ORDER_COUNT] = { "thu tu ngau nhien", "co thu tu dung", "co thu tu nguoc", "gan nhu co thu tu dung" };
	int size[SIZE_COUNT] = { 3000, 10000,30000,100000,300000 };
	void (*sortingAlg[SORTINGALG_COUNT])(int*, int) = { SelectionSort, InsertionSort,BubbleSort,MergeSort, QuickSort,HeapSort,BinaryInsertionSort };
	string sortingAlgName[SORTINGALG_COUNT] = { "selection sort", "insertion sort", "bubble sort", "merge sort", "quick sort", "heap sort", "binary insertion sort" };

	int n, * a;
	double sec;
	for (int i = 0; i < ORDER_COUNT; i++) {
		out << "--------------- Chay voi " << orderName[i] << " ---------------\n\n";
		for (int j = 0; j < SIZE_COUNT; j++) {
			out << "So luong " << size[j] << ": " << endl;
			n = size[j];
			for (int k = 0; k < SORTINGALG_COUNT; k++) {
				a = new int[n];

				GenerateData(a, n, i);
				sec = Cal_SortingAlg_Time(sortingAlg[k], a, n);

				out << "Thuat toan " << sortingAlgName[k] << ": " << sec << " giay" << endl;
				delete[]a;
			}
			out << endl;
		}
		out << "\n\n";
	}

	out.close();

}
