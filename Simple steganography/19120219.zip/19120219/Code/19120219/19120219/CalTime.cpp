#include "CalTime.h"

double Cal_SortingAlg_Time(void (*func)(int*, int), int* a, int n) {
	auto begin = high_resolution_clock::now();
	func(a, n);
	auto end = high_resolution_clock::now();
	int milisec = (int)duration_cast<milliseconds>(end - begin).count();
	double seconds = milisec / 1000.0;
	return seconds;
}