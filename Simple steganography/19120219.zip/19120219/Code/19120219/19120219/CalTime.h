#pragma once
#include <iostream>
#include <chrono>
using namespace std;
using namespace chrono;

double Cal_SortingAlg_Time(void(*func)(int*, int), int* a, int n);
